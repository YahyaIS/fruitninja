
package fruitninja;

public interface Level {
    public void manageLevel();
    public int getScore();
    public int getTime();
}
