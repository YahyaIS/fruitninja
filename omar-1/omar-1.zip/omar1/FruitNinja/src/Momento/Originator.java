package Momento;


import com.sun.jmx.snmp.BerDecoder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

public class Originator {
    Momento momento;
    public void save() throws ParserConfigurationException, SAXException, IOException{
        File xmlfile= new File("file:game.xml");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(xmlfile);
        doc.getDocumentElement().normalize();              
        String highscoreItoS = String.valueOf(momento.getHighscore());
            Element element = (Element) doc.getElementsByTagName("HighScore");
            element.setTextContent(highscoreItoS);
            
        }
    public int restore() throws ParserConfigurationException, SAXException, IOException{
        File xmlfile= new File("file:game.xml");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(xmlfile);
        doc.getDocumentElement().normalize(); 
        String highscoree = doc.getElementsByTagName("HighScore").item(0).getTextContent();
        int highscoreStoI = Integer.parseInt(highscoree);
        return highscoreStoI;
    }
    }

