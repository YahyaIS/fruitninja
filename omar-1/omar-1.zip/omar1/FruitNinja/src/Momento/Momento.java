package Momento;

public class Momento {
     private int highscore;
    
    public Momento(int highscore){
        this.highscore=highscore;
    }

    public int getHighscore() {
        return highscore;
    }

    public void setHighscore(int highscore) {
        this.highscore = highscore;
    }
}
